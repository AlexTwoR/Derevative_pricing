#ifndef ANTITHETIC_H
#define ANTITHETIC_H

#include "Random.h"

class AntiThetic : public BasicRandomGenerator
{

};


#endif
